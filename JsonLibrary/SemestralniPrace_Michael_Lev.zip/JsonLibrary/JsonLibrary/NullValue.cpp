#include "pch.h"
#include "api.h"

std::string NullValue::serialize() const
{
	return "null";
}